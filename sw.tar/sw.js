const C='tp2';
self.addEventListener('install',e=>e.waitUntil(caches.open(C).then(c=>c.addAll(['./','index.html','manifest.webmanifest','icon.svg']))));
self.addEventListener('fetch',e=>{if(e.request.url.includes('workers.dev'))return;e.respondWith(fetch(e.request).catch(()=>caches.match(e.request)))});
